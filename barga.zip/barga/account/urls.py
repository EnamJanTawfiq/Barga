from django.urls import path
from django.contrib.auth import views as auth_views
from .import views
from .views import UsersView,UserUpdateView



urlpatterns=[
    path('register/',views.registerPage,name='register'),
    path('login/',views.loginPage,name='login'),
    path('logout/',auth_views.LogoutView.as_view(template_name='account/logout.html'),name='logout'),
    path('users/',UsersView.as_view(),name='users'),
    path('user/<int:pk>/update/',UserUpdateView.as_view(),name='user-update'),
]

