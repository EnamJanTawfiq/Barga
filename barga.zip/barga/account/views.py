from django.db import models
from .forms import UserRegisterForm,UserUpdateForm
from django.contrib.auth import authenticate,login,logout
from django.shortcuts import render,redirect
from django.contrib import messages
from .decorators import unauthenticated_user,admin_only,allowed_user
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import View,UpdateView,ListView,DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.db.models import Q
from account.decorators import admin_only,student_only,allowed_user,allowed_vice_versa


@admin_only
def registerPage(request):
    if request.method=='POST':
        form=UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,f'شما موفقانه شخص جدید را درج سیستم نمودید')
            return redirect('users')
    else:
        form=UserRegisterForm()
    return render(request,'account/register.html',{'form':form})

@unauthenticated_user
def loginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
        else:
            messages.info(request,'لطفا اسم و رمز تانرا درست وارد نمایید')
            return redirect('login')
    return render(request,'account/login.html')





class UsersView(ListView):
    @allowed_user(allowed_roles=['admin'])
    def get(self,request,*args,**kwargs):
        users=User.objects.all().order_by('-date_joined')
        usersearch=request.GET.get('usersearch')
        if usersearch:
            users=User.objects.filter(
            Q(username__icontains=usersearch)
            ).order_by('-date_joined')
        paginator = Paginator(users,10)  
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)
        context={
            'page_obj':page_obj,
        }
        return render(request,'account/home.html',context)





class UserUpdateView(LoginRequiredMixin,UpdateView):
    model=User
    template_name='account/user_update.html'
    fields=['username']
    def get_success_url(self):
        return reverse_lazy('users')
    
