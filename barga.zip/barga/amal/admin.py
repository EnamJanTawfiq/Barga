from django.contrib import admin
from .models import B1Barga,Class,Teacher,B1Result



class B1BargaAdmin(admin.ModelAdmin):
    model=B1Barga
    list_display=('user','teacher','classess')
    search_fields=['user__username','teacher__name','classess__name']

admin.site.register(B1Barga,B1BargaAdmin)
admin.site.register(Class)
admin.site.register(Teacher)






admin.site.register(B1Result)

