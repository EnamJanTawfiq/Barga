from django.apps import AppConfig


class AmalConfig(AppConfig):
    name = 'amal'
