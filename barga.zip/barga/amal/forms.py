from django import forms
from .models import B1Barga,B1Result
from django.core.exceptions import ValidationError
class B1BargaForm(forms.ModelForm):

    class Meta:
        model=B1Barga
        fields = ['user','classess','teacher']
     


class B1ResultForm(forms.ModelForm):
    class Meta:
        model=B1Result
        fields = ['score','week']
        widgets={
            'score':forms.NumberInput(attrs={'min':'1','class':'form-control'}),
            'week':forms.NumberInput(attrs={'min':'1','week':'form-control'}),

        }
 

     