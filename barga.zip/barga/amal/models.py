from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models import CheckConstraint,Q,UniqueConstraint
from django.db import IntegrityError

class B1Barga(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='user')
    classess=models.ForeignKey('Class',on_delete=models.CASCADE)
    teacher=models.ForeignKey('Teacher',on_delete=models.CASCADE)
    author=models.ForeignKey(User,on_delete=models.CASCADE,related_name='author',null=True)
    q=models.CharField(max_length=3,null=True)
    m=models.CharField(max_length=3,null=True)
    j=models.CharField(max_length=3,null=True)
    telawat=models.CharField(max_length=3,null=True)
    tafakor=models.CharField(max_length=3,null=True)
    masnon=models.CharField(max_length=3,null=True)
    zekr165=models.CharField(max_length=3,null=True)
    mulk=models.CharField(max_length=3,null=True)
    sport=models.CharField(max_length=3,null=True)
    manzel=models.CharField(max_length=3,null=True)
    date_posted=models.DateTimeField(default=timezone.now)
    total=models.CharField(max_length=3,null=True)
    alltotal=models.CharField(max_length=5,null=True)
    
class Class(models.Model):
    name=models.CharField(max_length=10,blank=True,null=True,unique=True)
    
    def __str__(self):
        return self.name
class Teacher(models.Model):
    name=models.CharField(max_length=30,blank=True,null=True,unique=True)
    
    def __str__(self):
        return self.name
class B1Result (models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    week=models.IntegerField(null=True)
    score=models.FloatField(null=True)
    class Meta:
        unique_together=('user','week',)
        constraints=[
            CheckConstraint(
                check=Q(week__lt=21),
                name='هفته نباید بزرگ تر ۲۰ باشد',
            ),
         
            CheckConstraint(
                check=Q(score__lt=21),
                name='نتیجه باید بزرگ تر از ۲۰ نباشد',
            ),
            
            UniqueConstraint(
                fields=["user","week"],
                name='در این هفته از قبل اطلاعات درج نموده اید'
            )
        ]

     
