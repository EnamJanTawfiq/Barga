from django.urls import path
from . import views
from .views import B1BargaView,B1BargaCreateView,B1Detail,B1BargaDeleteView,B1ResultCreateView,B1BargaUpdateView,B1ResultUpdateView,B1ResultDeleteView
from django.contrib.auth import views as auth_views

urlpatterns=[
    path('', views.home,name='home'), 
    path('b1barga/',views.MyB1Barga,name='b1-barga'),  
    path('b1/', views.B1BargaView,name='b1-view'), 
    path('b1detail/<int:id>/',views.B1Detail,name='b1-detail'),
    path('b1detail/',views.myDetail,name='my-detail'),
    path('b1result/<int:id>/',views.B1ResultDetail,name='b1-result'),
    path('b1result/',views.MyResultDetail,name='my-result'),
    path('b1result/<int:pk>/update',B1ResultUpdateView.as_view(),name='b1-result-update'),
    path('b1result/<int:pk>/delete',B1ResultDeleteView.as_view(),name='b1-result-delete'),
    path('b1result/',views.B1ResultDetail,name='my-result'),
    path('b1barga/<int:pk>/delete/',B1BargaDeleteView.as_view(),name='b1-delete'),
    path('b1barga/new/',B1BargaCreateView.as_view(),name='b1barga-create'),
    path('result/new/',B1ResultCreateView.as_view(),name='b1result-create'),
    path('logout/',auth_views.LogoutView.as_view(template_name='account/login.html'),name='logout'),
    path('b1barga/<int:pk>/update/',B1BargaUpdateView.as_view(success_url="/"),name='b1-update'),

]