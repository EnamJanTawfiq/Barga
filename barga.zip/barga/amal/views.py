from django.shortcuts import render,redirect,get_object_or_404
from .models import B1Barga,B1Result
from django.contrib.auth.models import User
from django.views.generic import View,ListView,DetailView,CreateView,UpdateView,DeleteView
from django.views.generic import View,UpdateView
from django.core.paginator import Paginator
from .forms import B1BargaForm,B1ResultForm
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db.models import Q,Sum
from account.decorators import admin_only,student_only,allowed_user,allowed_vice_versa
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request,'amal/homes.html')


@login_required(login_url='login')
@student_only
def MyB1Barga(request):
    if request.method == 'POST':
        namaz1=request.POST.get('namaz1')
        namaz2=request.POST.get('namaz2')
        namaz3=request.POST.get('namaz3')
        namaz4=request.POST.get('namaz4')
        namaz5=request.POST.get('namaz5')
        namaz6=request.POST.get('namaz6')
        namaz7=request.POST.get('namaz7')
        namaz8=request.POST.get('namaz8')
        namaz9=request.POST.get('namaz9')
        namaz10=request.POST.get('namaz10')
        namaz11=request.POST.get('namaz11')
        namaz12=request.POST.get('namaz12')
        namaz13=request.POST.get('namaz13')
        namaz14=request.POST.get('namaz14')
        namaz15=request.POST.get('namaz15')
        namaz16=request.POST.get('namaz16')
        namaz17=request.POST.get('namaz17')
        namaz18=request.POST.get('namaz18')
        namaz19=request.POST.get('namaz19')
        namaz20=request.POST.get('namaz20')
        namaz21=request.POST.get('namaz21')
        namaz22=request.POST.get('namaz22')
        namaz23=request.POST.get('namaz23')
        namaz24=request.POST.get('namaz24')
        namaz25=request.POST.get('namaz25')
        namaz26=request.POST.get('namaz26')
        namaz27=request.POST.get('namaz27')
        namaz28=request.POST.get('namaz28')
        namaz29=request.POST.get('namaz29')
        namaz30=request.POST.get('namaz30')
        namaz31=request.POST.get('namaz31')
        namaz32=request.POST.get('namaz32')
        namaz33=request.POST.get('namaz33')
        namaz34=request.POST.get('namaz34')
        namaz35=request.POST.get('namaz35')
        namaz36=request.POST.get('namaz36')
        namaz41=request.POST.get('namaz41')
        namaz46=request.POST.get('namaz46')
        namaz51=request.POST.get('namaz51')
        namaz56=request.POST.get('namaz56')
        namaz61=request.POST.get('namaz61')
        namaz66=request.POST.get('namaz66')
        namaz37=request.POST.get('namaz37')
        namaz42=request.POST.get('namaz42')
        namaz47=request.POST.get('namaz47')
        namaz52=request.POST.get('namaz52')
        namaz57=request.POST.get('namaz57')
        namaz62=request.POST.get('namaz62')
        namaz67=request.POST.get('namaz67')
        namaz38=request.POST.get('namaz38')
        namaz43=request.POST.get('namaz43')
        namaz48=request.POST.get('namaz48')
        namaz53=request.POST.get('namaz53')
        namaz58=request.POST.get('namaz58')
        namaz63=request.POST.get('namaz63')
        namaz68=request.POST.get('namaz68')
        namaz39=request.POST.get('namaz39')
        namaz44=request.POST.get('namaz44')
        namaz49=request.POST.get('namaz49')
        namaz54=request.POST.get('namaz54')
        namaz59=request.POST.get('namaz59')
        namaz64=request.POST.get('namaz64')
        namaz69=request.POST.get('namaz69')
        namaz40=request.POST.get('namaz40')
        namaz45=request.POST.get('namaz45')
        namaz50=request.POST.get('namaz50')
        namaz55=request.POST.get('namaz55')
        namaz60=request.POST.get('namaz60')
        namaz65=request.POST.get('namaz65')
        namaz70=request.POST.get('namaz70')

        namaz71=request.POST.get('namaz71')
        namaz72=request.POST.get('namaz72')
      


        
        result1=0 if namaz1 is None else int(namaz1)
        result2=0 if namaz2 is None else int(namaz2)
        result3=0 if namaz3 is None else int(namaz3)
        result4=0 if namaz4 is None else int(namaz4)
        result5=0 if namaz5 is None else int(namaz5)
        result6=0 if namaz6 is None else int(namaz6)
        result7=0 if namaz7 is None else int(namaz7)
        result8=0 if namaz8 is None else int(namaz8)
        result9=0 if namaz9 is None else int(namaz9)
        result10=0 if namaz10 is None else int(namaz10)
        result11=0 if namaz11 is None else int(namaz11)
        result12=0 if namaz12 is None else int(namaz12)
        result13=0 if namaz13 is None else int(namaz13)
        result14=0 if namaz14 is None else int(namaz14)
        result15=0 if namaz15 is None else int(namaz15)
        result16=0 if namaz16 is None else int(namaz16)
        result17=0 if namaz17 is None else int(namaz17)
        result18=0 if namaz18 is None else int(namaz18)
        result19=0 if namaz19 is None else int(namaz19)
        result20=0 if namaz20 is None else int(namaz20)
        result21=0 if namaz21 is None else int(namaz21)
        result22=0 if namaz22 is None else int(namaz22)
        result23=0 if namaz23 is None else int(namaz23)
        result24=0 if namaz24 is None else int(namaz24)
        result25=0 if namaz25 is None else int(namaz25)
        result26=0 if namaz26 is None else int(namaz26)
        result27=0 if namaz27 is None else int(namaz27)
        result28=0 if namaz28 is None else int(namaz28)
        result29=0 if namaz29 is None else int(namaz29)
        result30=0 if namaz30 is None else int(namaz30)
        result31=0 if namaz31 is None else int(namaz31)
        result32=0 if namaz32 is None else int(namaz32)
        result33=0 if namaz33 is None else int(namaz33)
        result34=0 if namaz34 is None else int(namaz34)
        result35=0 if namaz35 is None else int(namaz35)



        result36=0 if namaz36 is None else int(namaz36)
        result41=0 if namaz41 is None else int(namaz41)
        result46=0 if namaz46 is None else int(namaz46)
        result51=0 if namaz51 is None else int(namaz51)
        result56=0 if namaz56 is None else int(namaz56)
        result61=0 if namaz61 is None else int(namaz61)
        result66=0 if namaz66 is None else int(namaz66)

        

        result37=0 if namaz37 is None else int(namaz37)
        result42=0 if namaz42 is None else int(namaz42)
        result47=0 if namaz47 is None else int(namaz47)
        result52=0 if namaz52 is None else int(namaz52)
        result57=0 if namaz57 is None else int(namaz57)
        result62=0 if namaz62 is None else int(namaz62)
        result67=0 if namaz67 is None else int(namaz67)


        result38=0 if namaz38 is None else int(namaz38)
        result43=0 if namaz43 is None else int(namaz43)
        result48=0 if namaz48 is None else int(namaz48)
        result53=0 if namaz53 is None else int(namaz53)
        result58=0 if namaz58 is None else int(namaz58)
        result63=0 if namaz63 is None else int(namaz63)
        result68=0 if namaz68 is None else int(namaz68)


        result39=0 if namaz39 is None else int(namaz39)
        result44=0 if namaz44 is None else int(namaz44)
        result49=0 if namaz49 is None else int(namaz49)
        result54=0 if namaz54 is None else int(namaz54)
        result59=0 if namaz59 is None else int(namaz59)
        result64=0 if namaz64 is None else int(namaz64)
        result69=0 if namaz69 is None else int(namaz69)

        result40=0 if namaz40 is None else int(namaz40)
        result45=0 if namaz45 is None else int(namaz45)
        result50=0 if namaz50 is None else int(namaz50)
        result55=0 if namaz55 is None else int(namaz55)
        result60=0 if namaz60 is None else int(namaz60)
        result65=0 if namaz65 is None else int(namaz65)
        result70=0 if namaz70 is None else int(namaz70)

        result71=0 if namaz71 is None else int(namaz71)
        result72=0 if namaz72 is None else int(namaz72)


        namaz=result1+result2+result3+result4+result5+result6+result7+result8+result9+result10+result11+result12+result13+result14+result15+result16+result17+result18+result19+result20+result21+result22+result23+result24+result25+result26+result27+result28+result29+result30+result31+result32+result33+result34+result35
        mrs=[result1,result2,result3,result4,result5,result6,result7,result8,result9,result10,result11,result12,result13,result14,result15,result16,result17,result18,result19,result20,result21,result22,result23,result24,result25,result26,result27,result28,result29,result30,result31,result32,result33,result34,result35]
        j=mrs.count(2)
        m=mrs.count(1)
        q=mrs.count(0)
        j=round(j,2)
        m=round(m,2)
        q=round(q,2)

        telawat=result36+result41+result46+result51+result56+result61+result66

        tafakor=result37+result42+result47+result52+result57+result62+result67
    
        masnon=result38+result43+result48+result53+result58+result63+result68

        zekr165=result39+result44+result49+result54+result59+result64+result69

        mulk=result40+result45+result50+result55+result60+result65+result70

        manzel=result71
        
        sport=result72


        telawat1=int(telawat)*0.2
        telawat1=round(telawat1,2)

        tafakor1=int(tafakor)*0.4
        tafakor1=round(tafakor1,2)

        masnon1=int(masnon)*0.2
        masnon1=round(masnon1,2)

        zekr1651=int(zekr165)*0.2
        zekr1651=round(zekr1651,2)

        mulk1=int(mulk)*0.2
        mulk1=round(mulk1,2)


        sport1=int(sport)*0.4
        sport1=round(sport1,2)

        manzel1=int(manzel)*3
        manzel1=round(manzel1,2)

        jama=int(j)*0.2
        jama=round(jama,2)

        monf=int(m)*0
        monf=round(monf,2)

        qaza=int(q)*0
        qaza=round(qaza,2)

        total=telawat1+tafakor1+masnon1+zekr1651+mulk1+sport1+manzel1+jama+monf+qaza
        total=round(total,3)
        if total>19.5:
            total=20
       


        
        ptotal=((namaz+telawat+tafakor+masnon+zekr165+mulk+manzel+sport)/109)*100
        ptotal=round(ptotal,2)
        b1barga=B1Barga.objects.filter(user=request.user).update(j=j,m=m,q=q, telawat=telawat,tafakor=tafakor,masnon=masnon,zekr165=zekr165,mulk=mulk,manzel=manzel,sport=sport,total=total)
        if b1barga:
            messages.success(request,f'شما موفقانه اطلاعات خود را درج سیستم نمودید')
            return redirect('my-detail')
        else:
            messages.success(request,f'متاسف استیم تا حال برای شما برگه تنظیم نشده است')
        return render(request,'amal/B1Barga.html')

    return render(request,'amal/B1Barga.html')

@login_required(login_url='login')
@admin_only
def B1BargaView(request,*args,**kwargs):
    usersearch=request.GET.get('usersearch')
    classsearch=request.GET.get('classsearch')
    teachersearch=request.GET.get('teachersearch')
    page_obj=B1Barga.objects.all()
    if usersearch:
        page_obj=B1Barga.objects.filter(
        Q(user__username__icontains=usersearch)
        ).order_by('-total')
    if classsearch:
        page_obj=B1Barga.objects.filter(
        Q(classess__name__icontains=classsearch)
        ).order_by('-total')
    if teachersearch:
        page_obj=B1Barga.objects.filter(
        Q(teacher__name__icontains=teachersearch)
        ).order_by('-total')

    paginator = Paginator(page_obj,10)  
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    context={
        'page_obj':page_obj,
    }
    return render(request,'amal/home.html',context)


@login_required(login_url='login')
@admin_only
def B1Detail(request,id):
    b1=B1Barga.objects.get(user=id)
    context={
        'b1':b1,
    }
    return render(request,'amal/detail.html',context)



@login_required(login_url='login')
@student_only
def myDetail(request):
    b1=B1Barga.objects.get(user=request.user)
    context={
        'b1':b1,
    }
    return render(request,'amal/detail.html',context)



@login_required(login_url='login')
@admin_only
def B1ResultDetail(request,id):
    results = B1Result.objects.all().filter(user=id).order_by('week')
    context={
        'results':results,
       
    }
    return render(request,'amal/b1result.html',context)


@login_required(login_url='login')
@student_only
def MyResultDetail(request):
    sum=0
    sum=B1Result.objects.filter(user=request.user).aggregate(Sum('score'))['score__sum']
    if sum is None:
        sum=0
    x=sum/20
    x=round(x,2)
    B1Barga.objects.filter(user=request.user).update(alltotal=x)
    
    b1=B1Barga.objects.get(user=request.user)
    results=B1Result.objects.all().filter(user=request.user).order_by('week')
    context={
        'results':results,
    }
    return render(request,'amal/resultdetail.html',context)



class B1BargaCreateView(LoginRequiredMixin,CreateView):
    @allowed_user(allowed_roles=['admin','teachers'])
    def get(user,request,*args,**kwargs):
        form=B1BargaForm()
        context={
            'form':form,
        }
        return render(request,'amal/post_form.html',context)
    @allowed_user(allowed_roles=['admin','teachers'])
    def post(user,request,*args,**kwargs):
        form=B1BargaForm(request.POST)
        if form.is_valid():
            b1barga=form.save(commit=False)
            b1barga.author=request.user
            b1barga.save()
            return redirect('b1-barga')
        context={
            'form':form,
        }
        return render(request,'amal/post_form.html',context)

class B1ResultCreateView(LoginRequiredMixin,CreateView):
    @allowed_vice_versa(allowed_roles=['admin','teachers'])
    def get(user,request,*args,**kwargs):
        
        form=B1ResultForm()
        context={
            'form':form,
        }
        return render(request,'amal/b1resultcreate.html',context)
    @allowed_vice_versa(allowed_roles=['admin','teachers'])
    def post(user,request,*args,**kwargs):
        
        form=B1ResultForm(request.POST)
        if form.is_valid():            
            B1Result=form.save(commit=False)
            B1Result.user=request.user
            try:
                B1Result.save()
                
            except:
                messages.error(request,'در این هفته شما اطلاعات از قبل درج نموده اید')
                return redirect('b1result-create')
            return redirect('my-result')
        context={
            'form':form,
        }
        return render(request,'amal/b1resultcreate.html',context)

class B1ResultUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model=B1Result
    fields = ['score']
    template_name='amal/b1resultupdate.html'
    def get_success_url(self):
        return reverse_lazy('my-result')      
    def test_func(self):
        result=self.get_object()
        if self.request.user==result.user:
            return True
        return False 

class B1ResultDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model=B1Result
    success_message="نتیجه شخص را به موفقیت حذف نمودید"
    def get_success_url(self):
        return reverse_lazy('my-result')
    def delete(self,request,*args,**kwargs):
        messages.success(self.request,self.success_message)
        return super(B1ResultDeleteView,self).delete(request,*args,**kwargs)

    def test_func(self):
        result=self.get_object()
        if self.request.user==result.user:
            return True
        return False 


class B1BargaDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model=B1Barga
    success_url='/'
    success_message="برگه شخص را به موفقیت حذف نمودید"
    def delete(self,request,*args,**kwargs):
        messages.success(self.request,self.success_message)
        return super(B1BargaDeleteView,self).delete(request,*args,**kwargs)

    def test_func(self):
        barga=self.get_object()
        if self.request.user==barga.author:
            return True
        return False 




class B1BargaUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model=B1Barga
    fields = ['classess','teacher']
    template_name='amal/b1barga_update.html'

    def form_valid(self,form):
        form.instance.author=self.request.user
        return super().form_valid(form)
    
    def test_func(self):
        barga=self.get_object()
        if self.request.user==barga.author:
            return True
        return False 


   